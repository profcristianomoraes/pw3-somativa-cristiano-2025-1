import React from "react";
import style from './CreateBook.module.css'

const CreateBook = ()=>{
    return(
        <section>
            <h1>CREATE BOOK</h1>
        </section>
    )
}

export default CreateBook